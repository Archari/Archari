JDB - JSON Database
----

**19/04/2017**

**Info**
 - Build Database using JSON is very easy. no latency.
 - JDB is library for Python 2.7 for now
 - One Line datastore. 

with feature improvement like add, remove, delete, etc
info will be on the example

